package com.example.aaron_inventoryapp_option1;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private Cursor cursor;
    private OnDeleteListener listener;

    public interface OnDeleteListener { void onDelete(int id); }

    public InventoryAdapter(Cursor c, OnDeleteListener l) { this.cursor = c; this.listener = l; }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new ViewHolder(LayoutInflater.from(p.getContext()).inflate(R.layout.inventory_item, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        if (cursor.moveToPosition(pos)) {
            // Use column names to be safe
            final int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            h.name.setText(name);
            h.qty.setText("Stock: " + qty);
            h.del.setOnClickListener(v -> listener.onDelete(id));
        }
    }

    @Override
    public int getItemCount() { return cursor.getCount(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, qty; Button del;
        public ViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.item_name);
            qty = v.findViewById(R.id.item_qty);
            del = v.findViewById(R.id.btn_delete);
        }
    }
}