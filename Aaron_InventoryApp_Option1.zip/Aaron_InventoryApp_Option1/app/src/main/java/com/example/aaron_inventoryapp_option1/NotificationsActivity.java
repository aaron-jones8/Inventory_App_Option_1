package com.example.aaron_inventoryapp_option1;

import com.google.android.material.materialswitch.MaterialSwitch;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private MaterialSwitch smsSwitch;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        smsSwitch = findViewById(R.id.sms_permission_switch);
        statusText = findViewById(R.id.permission_status);

        // Check current permission status
        checkPermissionStatus();

        smsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // If user turns switch ON, request permission
                    requestSmsPermission();
                } else {
                    statusText.setText("Status: Alerts Disabled");
                    statusText.setTextColor(getResources().getColor(android.R.color.darker_gray));
                }
            }
        });
    }

    private void checkPermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsSwitch.setChecked(true);
            statusText.setText("Status: Active");
            statusText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            smsSwitch.setChecked(false);
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                statusText.setText("Status: Active");
                statusText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                smsSwitch.setChecked(false);
                statusText.setText("Status: Permission Denied");
                statusText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}