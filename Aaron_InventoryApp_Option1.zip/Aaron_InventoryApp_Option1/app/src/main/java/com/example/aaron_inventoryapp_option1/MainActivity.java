package com.example.aaron_inventoryapp_option1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText userIn, passIn;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);
        userIn = findViewById(R.id.nameText);
        passIn = findViewById(R.id.passwordText);
    }

    public void onLoginClick(View v) {
        if (db.checkUser(userIn.getText().toString(), passIn.getText().toString())) {
            startActivity(new Intent(this, InventoryActivity.class));
        } else {
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }

    public void onCreateAccountClick(View v) {
        if (db.addUser(userIn.getText().toString(), passIn.getText().toString())) {
            Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show();
        }
    }
}