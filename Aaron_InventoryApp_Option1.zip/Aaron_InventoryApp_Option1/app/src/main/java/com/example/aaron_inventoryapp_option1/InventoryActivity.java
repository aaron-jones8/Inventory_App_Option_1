package com.example.aaron_inventoryapp_option1;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private InventoryAdapter adapter;
    private RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        db = new DatabaseHelper(this);
        rv = findViewById(R.id.recycler_view);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        refreshGrid();

        findViewById(R.id.btn_nav_notifications).setOnClickListener(v ->
                startActivity(new Intent(this, NotificationsActivity.class)));

        findViewById(R.id.fab_add_item).setOnClickListener(v -> {
            db.addItem("New Item", 10); // Placeholder for adding data
            refreshGrid();
        });
    }

    private void refreshGrid() {
        Cursor cursor = db.getAllItems();
        adapter = new InventoryAdapter(cursor, id -> {
            db.deleteItem(id);
            refreshGrid();
        });
        rv.setAdapter(adapter);
    }
}